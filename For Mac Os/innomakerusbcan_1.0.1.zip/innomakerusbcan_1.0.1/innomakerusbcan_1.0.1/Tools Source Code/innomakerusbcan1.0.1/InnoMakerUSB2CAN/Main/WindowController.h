//
//  WindowController.h
//  InnoMakerUSB2CAN
//
//  Created by SUGAR Dev on 2020/4/26.
//  Copyright © 2020 Yanci. All rights reserved.
//

#import <Cocoa/Cocoa.h>

NS_ASSUME_NONNULL_BEGIN

@interface WindowController : NSWindowController

@end

NS_ASSUME_NONNULL_END
