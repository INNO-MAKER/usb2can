//
//  AppDelegate.m
//  InnoMakerUSB2CAN
//
//  Created by Inno-Maker on 2020/4/3.
//  Copyright © 2020 Inno-Maker. All rights reserved.
//

#import "AppDelegate.h"

@interface AppDelegate ()

@end

@implementation AppDelegate

- (void)applicationDidFinishLaunching:(NSNotification *)aNotification {
    // Insert code here to initialize your application
 
}


- (void)applicationWillTerminate:(NSNotification *)aNotification {
    // Insert code here to tear down your application
}


@end
