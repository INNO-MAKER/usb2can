//
//  AppDelegate.h
//  InnoMakerUSB2CAN
//
//  Created by Inno-Maker on 2020/4/3.
//  Copyright © 2020 Inno-Maker. All rights reserved.
//

#import <Cocoa/Cocoa.h>

@interface AppDelegate : NSObject <NSApplicationDelegate>


@end

	
