//
//  NSData+HexPresention.h
//  InnoMakerUSB2CAN
//
//  Created by SUGAR Dev on 2020/4/13.
//  Copyright © 2020 Inno-Maker. All rights reserved.
//

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN
@interface NSData (HexPresention)
- (NSString *)hexString;
@end
NS_ASSUME_NONNULL_END
