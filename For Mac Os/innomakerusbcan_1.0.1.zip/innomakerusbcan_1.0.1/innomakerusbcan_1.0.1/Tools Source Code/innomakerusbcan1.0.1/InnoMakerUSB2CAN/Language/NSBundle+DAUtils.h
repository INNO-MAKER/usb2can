
#import <Foundation/Foundation.h>

@interface NSBundle (DAUtils)

+ (BOOL)isChineseLanguage;

+ (NSString *)currentLanguage;

@end
