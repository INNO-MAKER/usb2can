package com.example.socketcan;


import static android.hardware.usb.UsbConstants.USB_DIR_IN;
import static android.hardware.usb.UsbConstants.USB_DIR_OUT;
import static android.hardware.usb.UsbConstants.USB_ENDPOINT_XFER_BULK;

import android.app.PendingIntent;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.hardware.usb.UsbDevice;
import android.hardware.usb.UsbDeviceConnection;
import android.hardware.usb.UsbEndpoint;
import android.hardware.usb.UsbInterface;
import android.hardware.usb.UsbManager;
import android.util.Log;

import java.nio.ByteBuffer;
import java.nio.ByteOrder;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.concurrent.atomic.AtomicReference;

/* ANDROID LIB */
public class LibInnoMakerUsbCan {
     int CAN_EFF_FLAG = 0x80000000;
     int CAN_RTR_FLAG = 0x40000000;
     int CAN_ERR_FLAG = 0x20000000;

     int CAN_SFF_MASK  =0x000007FF;
     int CAN_EFF_MASK = 0x1FFFFFFF;
     int CAN_ERR_MASK = 0x1FFFFFFF;
     int CAN_ID_MASK  = 0x1FFFFFFF;

    /* error class (mask) in can_id */
     int CAN_ERR_CRTL = 0x00000004;
     int CAN_ERR_BUSOFF = 0x00000040;
     int CAN_ERR_RESTARTED = 0x00000100;

    /* error status of CAN-controller / data[1] */
     int CAN_ERR_CRTL_UNSPEC    = 0x00;
     int CAN_ERR_CRTL_RX_OVERFLOW  =0x01;
     int CAN_ERR_CRTL_TX_OVERFLOW = 0x02;
     int CAN_ERR_CRTL_RX_WARNING  = 0x04;
     int CAN_ERR_CRTL_TX_WARNING = 0x08;
     int CAN_ERR_CRTL_RX_PASSIVE  = 0x10;
     int CAN_ERR_CRTL_TX_PASSIVE = 0x20;
     int CAN_SFF_ID_BITS   =    11;
     int CAN_EFF_ID_BITS =      29;

    /// MAX TX URBS
     int innomaker_MAX_TX_URBS = 10;


     class SpinLock
    {
        private AtomicReference<Thread> cas;
        SpinLock(AtomicReference<Thread> cas){
            this.cas = cas;
        }
        public void lock() {
            Thread current = Thread.currentThread();

            while (!cas.compareAndSet(null, current)) {

                System.out.println("I am spinning");
            }
        }

        public void unlock() {
            Thread current = Thread.currentThread();
            cas.compareAndSet(current, null);
        }
    }

    static class InnoMakerHostFrame
    {

        int echo_id;
        int can_id;
        byte can_dlc;
        byte channel;
        byte flags;
        byte reserved;
        byte[] data = new byte[8];
        int timestamp_us;

        byte[] toBytes() {
            byte[] bytes = new byte[24];
            byte[] echo_id_b = intToByteArray(echo_id);
            byte[] can_id_b = intToByteArray(can_id);
            byte[] timestamp_us_b = intToByteArray(timestamp_us);
            System.arraycopy(echo_id_b, 0, bytes, 0, 4);
            System.arraycopy(can_id_b, 0, bytes, 4, 4);
            bytes[8] = can_dlc;
            bytes[9] = channel;
            bytes[10] = flags;
            bytes[11] = reserved;
            System.arraycopy(data, 0, bytes, 12, 8);
            System.arraycopy(timestamp_us_b, 0, bytes, 20, 4);
            return bytes;
        }

        void fromBytes(byte[] bytes) {
            byte []toIntBytes = new byte[4];
            System.arraycopy(bytes,0,toIntBytes,0,4);
            echo_id = intFromByteArray(toIntBytes);

            System.arraycopy(bytes,4,toIntBytes,0,4);
            can_id = intFromByteArray(toIntBytes);

            can_dlc = bytes[8];
            channel = bytes[9];
            flags = bytes[10];
            reserved = bytes[11];
            System.arraycopy(bytes,12,data,0,8);

            System.arraycopy(bytes,20,toIntBytes,0,4);
            timestamp_us = intFromByteArray(toIntBytes);
        }

        /// Int to bytes
        byte[] intToByteArray(int value) {
            return ByteBuffer.allocate(4).order(ByteOrder.LITTLE_ENDIAN).putInt(value).array();
        }

        /// int from bytes
        int intFromByteArray(byte[] bytes) {
            ByteBuffer wrapped = ByteBuffer.wrap(bytes).order(ByteOrder.LITTLE_ENDIAN);
            return wrapped.getInt();
        }
    }

     class InnoMakerTxContext
    {
        int echo_id;
    };

     static class InnoMakerCanTransfer
    {
        /* This lock prevents a race condition between xmit and receive. */
        SpinLock tx_ctx_lock;
        InnoMakerTxContext[]tx_context;
    };

     InnoMakerTxContext innomakerAllocTxContent()
    {
        InnoMakerCanTransfer dev= innoMakerCan;
        boolean _lock = false;
        dev.tx_ctx_lock.lock();
        for(int i = 0; i < innomaker_MAX_TX_URBS; i++) {
            if(dev.tx_context[i].echo_id == innomaker_MAX_TX_URBS) {
                dev.tx_context[i].echo_id = i;
                dev.tx_ctx_lock.unlock();
                return  dev.tx_context[i];
            }
        }

        dev.tx_ctx_lock.unlock();
        _lock = false;

        InnoMakerTxContext nullContext = new InnoMakerTxContext();
        nullContext.echo_id = 0xff;
        return nullContext;
    }

     void innomakerFreeTxContent(InnoMakerTxContext txContext)
    {
        if(txContext != null) {
            txContext.echo_id = innomaker_MAX_TX_URBS;
        }
    }

     InnoMakerTxContext innomakerGetTxContext(int id)

    {
        InnoMakerCanTransfer dev = innoMakerCan;
        if(id < innomaker_MAX_TX_URBS) {
            dev.tx_ctx_lock.lock();
            if(dev.tx_context[id].echo_id == id) {
                dev.tx_ctx_lock.unlock();
                return dev.tx_context[id];
            }
            dev.tx_ctx_lock.unlock();
        }
        return null;
    }

     String bytesToHexString(byte[] src){
        StringBuilder stringBuilder = new StringBuilder("");
        if (src == null || src.length <= 0) {
            return null;
        }
        for (int i = 0; i < src.length; i++) {
            int v = src[i] & 0xFF;
            String hv = Integer.toHexString(v);
            if (hv.length() < 2) {
                stringBuilder.append(0);
            }
            stringBuilder.append(hv);

            stringBuilder.append(" ");
        }
        return stringBuilder.toString();
    }
    /// Int to bytes
      byte[] intToByteArray(int value) {
        return ByteBuffer.allocate(4).order(ByteOrder.LITTLE_ENDIAN).putInt(value).array();
      }

    /// int from bytes
     int intFromByteArray(byte[] bytes) {
          ByteBuffer wrapped = ByteBuffer.wrap(bytes).order(ByteOrder.LITTLE_ENDIAN);
         return wrapped.getInt();
    }

    /// LIB USB FUNC
    public native boolean setup();
    public native  boolean setdown();
    /*
     canmode = 1 (normal) canmode = 2 (loopback) canmode = 1 (listen)
     bittmingType index from 0 ( 0 - 20K , 1 - 33.33K ...)
     "20K", "33.33K", "40K", "50K", "66.66K", "80K", "83.33K", "100K", "125K",
     "200K", "250K", "400K", "500K", "666K", "800K", "1000K"
    */
    public native boolean urbSetupDevice(int fd, int canmode, int bittmingType);
    public native boolean sendInnoMakerDeviceBuf(int fd, byte[] buffer, int size,int timeout);
    public native boolean recvInnoMakerDeviceBuf(int fd, byte[] buffer, int size,int timeout);

     {
        System.loadLibrary("usbcan");
    }

    private  String ACTION_USB_PERMISSION = "android.hardware.usb.action.ACTION_USB_PERMISSION";
    private  String ACTION_USB_ACCESSORY_DETACHED = "android.hardware.usb.action.USB_ACCESSORY_DETACHED";
    private  String ACTION_USB_DEVICE_ATTACH= "android.hardware.usb.action.USB_DEVICE_ATTACHED";

    /// Usb Manager
    UsbManager usbManager;
    Context context;
    /// Device List
    ArrayList<UsbDevice> deviceList = new ArrayList<UsbDevice>();
    /// Device Connection Map
    HashMap<Integer,UsbDeviceConnection> deviceConnectionHashMap = new HashMap<Integer, UsbDeviceConnection>();
    InnoMakerCanTransfer innoMakerCan;
    UsbEndpoint curReadEndpoint;
    UsbEndpoint curWriteEndpoint;

    LibInnoMakerUsbCan(UsbManager _usbManager_,Context _context_) {
       usbManager = _usbManager_;
       context = _context_;
    }

   

    boolean jScanInnoMakerDevice() {
        deviceList.clear();
        HashMap<String,UsbDevice> deviceListMap  = usbManager.getDeviceList();
        for (UsbDevice usbDevice : deviceListMap.values()) {
            deviceList.add(usbDevice);
        }
        return  true;
    }

    UsbDeviceConnection jOpenInnoMakerDevice(int deviceIndex) {
        setup();
        UsbDevice usbDevice = deviceList.get(deviceIndex);
        if(usbDevice == null) return  null;
        if(!usbManager.hasPermission(usbDevice)) {
            jRequestInnoMakeDevicePermission(deviceIndex);
            return null;
        }
        UsbDeviceConnection usbDeviceConnection = usbManager.openDevice(usbDevice);

        if(usbDeviceConnection == null) return null;
        getEndPoint(usbDevice);
        deviceConnectionHashMap.put(usbDevice.getDeviceId(),usbDeviceConnection);

        /// Reset transfer
        innoMakerCan = new InnoMakerCanTransfer();
        innoMakerCan.tx_ctx_lock = new SpinLock(new AtomicReference<>());
        innoMakerCan.tx_context = new InnoMakerTxContext[innomaker_MAX_TX_URBS];
        for (int i = 0; i < innomaker_MAX_TX_URBS; i++) {
            innoMakerCan.tx_context[i] = new InnoMakerTxContext();
            innoMakerCan.tx_context[i].echo_id = innomaker_MAX_TX_URBS;
        }
        ///  Start recv thead

        return  usbDeviceConnection;
    }

    boolean jRequestInnoMakeDevicePermission(int deviceIndex) {
        UsbDevice usbDevice = deviceList.get(deviceIndex);
        if(usbManager.hasPermission(usbDevice)) {
            return true;
        }
        PendingIntent mPermissionIntent = PendingIntent.getBroadcast(context, 0, new Intent(
                ACTION_USB_PERMISSION), 0);
        usbManager.requestPermission(usbDevice, mPermissionIntent);
        return  true;
    }

    int jGetInnoMakerDeviceCount() {
        return  deviceList.size();
    }

    void getEndPoint(UsbDevice usbDevice) {
        UsbEndpoint vPointRead = null;
        UsbEndpoint	vPointWrite = null;
        int			vInterfaceNumber = 0;

        for (int vIndex = 0; vIndex < usbDevice.getInterfaceCount(); ++vIndex)
        {
            UsbInterface intf = usbDevice.getInterface(vIndex);
            vInterfaceNumber = vIndex;
            break;
        }

        UsbInterface vInterface = usbDevice.getInterface(vInterfaceNumber);
        for (int vIndex = 0; vIndex < vInterface.getEndpointCount(); ++vIndex)
        {
            UsbEndpoint point = vInterface.getEndpoint(vIndex);
            if (point.getType() ==  USB_ENDPOINT_XFER_BULK)
            {
                if (vPointRead == null && point.getDirection() == USB_DIR_IN)
                {
                    vPointRead = point;
                    curReadEndpoint = point;
                }
                else if (vPointWrite == null && point.getDirection() == USB_DIR_OUT)
                {
                    vPointWrite = point;
                    curWriteEndpoint = point;
                }
            }
        }

    }

    boolean jCloseInnoMakerDevice(int deviceIndex) {

        UsbDevice usbDevice = deviceList.get(deviceIndex);
        if(usbDevice == null) return  false;
        UsbDeviceConnection usbDeviceConnection = deviceConnectionHashMap.get(usbDevice.getDeviceId());
        deviceConnectionHashMap.remove(usbDevice.getDeviceId());
        if(usbDeviceConnection == null)return false;
        usbDeviceConnection.close();
        curWriteEndpoint = null;
        curReadEndpoint = null;
        setdown();
        return true;
    }

    boolean jSendInnoMakerDeviceBuf(UsbDevice usbDevice, byte[] buffer, int size,int timeout) {
//        if(currentConnection == null || curWriteEndpoint == null) return false;
//        currentConnection.bulkTransfer(curWriteEndpoint, buffer,size,timeout);
        UsbDeviceConnection deviceConnection = deviceConnectionHashMap.get(usbDevice.getDeviceId());
        if(deviceConnection == null || curWriteEndpoint == null) return  false;
        deviceConnection.bulkTransfer(curWriteEndpoint, buffer,size,timeout);
//        sendInnoMakerDeviceBuf(deviceConnection.getFileDescriptor(),buffer,size,timeout);
        return true;
    }

    boolean jRecvInnoMakerDeviceBuf(UsbDevice usbDevice, byte[] buffer, int size,int timeout) {
//        if(currentConnection == null || curReadEndpoint == null) return false;
//        currentConnection.bulkTransfer(curReadEndpoint, buffer,size,timeout);

        UsbDeviceConnection deviceConnection = deviceConnectionHashMap.get(usbDevice.getDeviceId());
        if(deviceConnection == null || curReadEndpoint == null) return  false;
        deviceConnection.bulkTransfer(curReadEndpoint, buffer,size,timeout);
//        recvInnoMakerDeviceBuf(deviceConnection.getFileDescriptor(),buffer,size,timeout);
        return true;
    }

    /// 构造标准帧
    byte []buildStandardFrame(int curFrameFormat,int curFrameType, String frameId,String frameData,int echoId) {
        String []frameDataStrs = frameData.split(" ");
        String []frameIdStrs = frameId.split(" ");
        byte []frameIdBytes = new byte[4];

        /// 01 02 03 04 ==> 04 03 02 01  / little endian
        for(int i = 0; i < frameIdStrs.length; i++) {
            if(i  < frameIdBytes.length ) {
                frameIdBytes[ 3 - i ] = (byte) Integer.parseInt(frameIdStrs[i], 16);
            } else {
                frameIdBytes[ 3- i ] = 0;
            }
        }

        InnoMakerHostFrame hostFrame = new InnoMakerHostFrame();
        hostFrame.echo_id = echoId;
        hostFrame.can_id = intFromByteArray(frameIdBytes);
        hostFrame.can_dlc = (byte) frameDataStrs.length;
        hostFrame.channel = 0;
        hostFrame.flags = 0;
        hostFrame.reserved = 0;

        if(curFrameFormat == 1) {
            hostFrame.can_id |= CAN_EFF_FLAG;
        }
        if(curFrameType == 1) {
            hostFrame.can_id |= CAN_RTR_FLAG;
        }
        for(int i = 0; i < frameDataStrs.length; i++) {
            if(i < hostFrame.data.length ) {
                hostFrame.data[i] = (byte) Integer.parseUnsignedInt(frameDataStrs[i], 16);
            }
        }
        return hostFrame.toBytes();
    }


}
