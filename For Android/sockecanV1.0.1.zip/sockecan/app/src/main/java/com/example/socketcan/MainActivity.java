package com.example.socketcan;

import androidx.appcompat.app.AppCompatActivity;
import android.app.AlertDialog;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.IntentFilter;
import android.hardware.usb.UsbDevice;
import android.hardware.usb.UsbDeviceConnection;
import android.hardware.usb.UsbManager;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.text.InputFilter;
import android.text.method.ScrollingMovementMethod;
import android.util.Log;
import android.view.View;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ScrollView;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import org.w3c.dom.Text;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity  {

    {
        System.loadLibrary("usb1.0");
        System.loadLibrary("usbcan");
    }

    private  String ACTION_USB_PERMISSION = "android.hardware.usb.action.ACTION_USB_PERMISSION";
    private  String ACTION_USB_ACCESSORY_DETACHED = "android.hardware.usb.action.USB_DEVICE_DETACHED";
    private  String ACTION_USB_DEVICE_ATTACH= "android.hardware.usb.action.USB_DEVICE_ATTACHED";

    /// LibUsbCan Instance
    LibInnoMakerUsbCan libInnoMakerUsbCan;
    /// Current transfer
//    LibInnoMakerUsbCan.InnoMakerCanTransfer innoMakerCan;

    /// 设备监听
    private final BroadcastReceiver mUsbRecever = new BroadcastReceiver() {
        @Override
        public void onReceive(Context context, Intent intent) {
            String vAction = intent.getAction();
            if(vAction.equals(ACTION_USB_PERMISSION)) {
                synchronized (this) {
                    UsbDevice device = intent.getParcelableExtra(UsbManager.EXTRA_DEVICE);
                    if(device != null) {
                        Toast.makeText(context, "Request permission success", Toast.LENGTH_SHORT).show();
                    }
                    else {
                        Toast.makeText(context, "Request permission fail", Toast.LENGTH_SHORT).show();
                    }
                }
            }
            else if(vAction.equals(ACTION_USB_ACCESSORY_DETACHED)) {
                UsbDevice device = intent.getParcelableExtra(UsbManager.EXTRA_DEVICE);
                if(device != null) {
                    Toast.makeText(context, "Device Disconnect", Toast.LENGTH_SHORT).show();
                }
                else {
                    Toast.makeText(context, "Device Disconnect", Toast.LENGTH_SHORT).show();
                }
                boolean isExist = false;
                for (UsbDevice _device:libInnoMakerUsbCan.deviceList
                ) {
                    if(_device.getDeviceId() == device.getDeviceId()) {
                        isExist= true;
                        if(currentDevice.getDeviceId() == _device.getDeviceId()) {

                            libInnoMakerUsbCan.jCloseInnoMakerDevice(libInnoMakerUsbCan.deviceList.indexOf(currentDevice));
                            currentDevice =null;
                            currentBittmingIndex = 0;
                            currentUsbMode = 0;
                            controlButton.setText("OPEN");
                        }
                    }
                }
                if(isExist) {
                    libInnoMakerUsbCan.deviceList.remove(device);
                }
            }
            else if(vAction.equals(ACTION_USB_DEVICE_ATTACH)) {

            }
        }
    };
    /// Current Device
    UsbDevice currentDevice;
    /// Current Usb Mode
    int currentUsbMode;
    /// Current Bittming Index
    int currentBittmingIndex;
    /// Current Frame format
    int curFrameFormat = 0;  /// 0 - standard, 1 - extended
    /// Current Frame Data Len
    int curFrameDataLen = 0;
    /// Current Frame Type
    int curFrameType = 0; /// 0 - data , 1 - remote
    /// Current connection
//    UsbDeviceConnection currentConnection;
    /// Recv thread
    Thread recvThread;
    /// Control button
    Button controlButton;
    /// Console TextView
    TextView consoleTextView;
    /// MHandler for update ui
    Handler mHandler;
    /// Frame ID EditText
    EditText frameIdEditText;
    /// Frame Data EditTExt
    EditText frameDataEditText;
    /// Application TextView
    TextView applicationTextView;

    ScrollView scrollView;


    int curErrorFilter = 0; /// 0 - 过滤错误， 1 - 不过滤错误

    int txCounter = 0;
    int rxCounter = 0;

    @Override
    protected void onDestroy() {
        super.onDestroy();

    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        setContentView(R.layout.activity_main);
        scrollView= (ScrollView)findViewById(R.id.console_text_view_container);
        consoleTextView = (TextView) findViewById(R.id.console_text_view);
//        consoleTextView.setMovementMethod(ScrollingMovementMethod.getInstance());

        libInnoMakerUsbCan =  new LibInnoMakerUsbCan((UsbManager) getSystemService(Context.USB_SERVICE),this);
//        innoMakerCan = new LibInnoMakerUsbCan.InnoMakerCanTransfer();
        /// 注册设备监听
        IntentFilter vFilter = new IntentFilter();
        vFilter.addAction(ACTION_USB_PERMISSION);
        vFilter.addAction(ACTION_USB_DEVICE_ATTACH);
        vFilter.addAction(ACTION_USB_ACCESSORY_DETACHED);
        registerReceiver(mUsbRecever,vFilter);

        final Button clearButton = (Button) findViewById(R.id.button_clear);
        clearButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                consoleTextView.setText("");
                txCounter = 0;
                rxCounter = 0;
                applicationTextView.setText("APPLICATE " + "TX:" + String.valueOf(txCounter) + " " + "RX:" + String.valueOf(rxCounter));
            }
        });

        final Button sendDataButton = (Button) findViewById(R.id.button_send_data);
        sendDataButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if(currentDevice == null) return;
                LibInnoMakerUsbCan.InnoMakerTxContext txContext = libInnoMakerUsbCan.innomakerAllocTxContent();
                if(txContext.echo_id == 0xff) {
                    Log.i("", "SEND FAIL: NETDEV_BUSY");
                    consoleTextView.append("SEND FAIL: NETDEV_BUSY \n");
                    return;
                }
                /// SEND CAN DATA
                byte[]framebytes = libInnoMakerUsbCan.buildStandardFrame(curFrameFormat,curFrameType, frameIdEditText.getText().toString(),frameDataEditText.getText().toString(),txContext.echo_id);
                boolean result = libInnoMakerUsbCan.jSendInnoMakerDeviceBuf(currentDevice,framebytes,24,5);
                if(result) {

                }
                else {
                    consoleTextView.append("SEND FAIL:" + framebytes.toString()+ "\n");
                }
            }
        });

        Context _this = this;
        controlButton = (Button) findViewById(R.id.button_stop_can);
        controlButton.setText("OPEN");
        controlButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if(currentDevice == null) {
                    /// 弹出设备选择列表
                    /// 选择列表项目，选择模式，选择波特率
                    alertChooseDeviceDialog();
                } else {
                    /// 关闭设备
                    libInnoMakerUsbCan.jCloseInnoMakerDevice( libInnoMakerUsbCan.deviceList.indexOf(currentDevice));
                    currentDevice =null;
                    currentBittmingIndex = 0;
                    currentUsbMode = 0;
                    controlButton.setText("OPEN");
                }
            }
        });

        frameIdEditText = (EditText) findViewById(R.id.edit_text_frame_id);
        frameIdEditText.addTextChangedListener( new CustomTextWatcher(frameIdEditText));
        frameIdEditText.setFilters(new InputFilter[]{new InputFilter.LengthFilter(11)});

        frameDataEditText = (EditText) findViewById(R.id.edit_text_frame_data);
        frameDataEditText.addTextChangedListener(new CustomTextWatcher(frameDataEditText));
        frameDataEditText.setFilters(new InputFilter[]{new InputFilter.LengthFilter(23)});

        final Spinner frameFormatSpinner = (Spinner) findViewById(R.id.spinner_frame_format);

        frameFormatSpinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> adapterView, View view, int i, long l) {
                    curFrameFormat = i;
            }

            @Override
            public void onNothingSelected(AdapterView<?> adapterView) {

            }
        });

        final Spinner frameLenSpinner = (Spinner) findViewById(R.id.spinner_frame_len);
        frameLenSpinner.setSelection(7);
        frameLenSpinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> adapterView, View view, int i, long l) {
                curFrameDataLen = i + 1;
                frameDataEditText.setText("");
                frameDataEditText.setFilters(new InputFilter[]{new InputFilter.LengthFilter(2 * curFrameDataLen + curFrameDataLen - 1 <= 0 ? 0 : 2 * curFrameDataLen + curFrameDataLen - 1)});
                frameDataEditText.setText("0000000000000000");
            }
            @Override
            public void onNothingSelected(AdapterView<?> adapterView) {

            }
        });

        final Spinner frameFilterError = (Spinner) findViewById(R.id.spinner_frame_filter_error);
        frameFilterError.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> adapterView, View view, int i, long l) {
                curErrorFilter = i;
            }
            @Override
            public void onNothingSelected(AdapterView<?> adapterView) {

            }
        });

        final  Spinner frameTypeSpinner = (Spinner) findViewById(R.id.spinner_frame_type);
        frameTypeSpinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> adapterView, View view, int i, long l) {
                  curFrameType = i;
            }

            @Override
            public void onNothingSelected(AdapterView<?> adapterView) {

            }
        });
        applicationTextView = (TextView)findViewById(R.id.application_text_view);
        applicationTextView.setText("APPLICATE " + "TX:" + String.valueOf(txCounter) + " " + "RX:" + String.valueOf(rxCounter));

         mHandler = new Handler() {

            @Override
            public void handleMessage(Message msg) {
                super.handleMessage(msg);
                switch (msg.what) {
                    case 0:
                        //完成主界面更新,拿到数据
                        String data = (String)msg.obj;
                        consoleTextView.append(data);
                        applicationTextView.setText("APPLICATE " + "TX:" + String.valueOf(txCounter) + " " + "RX:" + String.valueOf(rxCounter));
                        scrollView.post(new Runnable() {
                            @Override
                            public void run() {
                                scrollView.fullScroll(ScrollView.FOCUS_DOWN);
                            }
                        });
                        break;
                    default:
                        break;
                }
            }

        };

    }

    /// 选择设备对话框
    void  alertChooseDeviceDialog() {
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setTitle("Choose a device");
        ArrayList<String> animals = new ArrayList<>();
        libInnoMakerUsbCan.jScanInnoMakerDevice();
        String devNames[] = new String[libInnoMakerUsbCan.deviceList.size()];
        for(int i = 0; i < devNames.length;i++) {
            devNames[i] = String.valueOf(i); // String.valueOf(libInnoMakerUsbCan.deviceList.get(i).getDeviceId());
        }
        builder.setItems(devNames, new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                currentDevice =  libInnoMakerUsbCan.deviceList.get(which);
                alertChooseUsbMode();
            }
        });

        AlertDialog dialog = builder.create();
        dialog.show();
    }

    /// 选择USB模式对话框
    void alertChooseUsbMode() {
        // setup the alert builder
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setTitle("Choose an usb mode");
        // add a list
        String[] modes = {"normal", "loopback", "listen"};
        builder.setItems(modes, new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                currentUsbMode = which + 1;
                alertChooseBittmingMode();
            }
        });
        AlertDialog dialog = builder.create();
        dialog.show();
    }

    /// 选择比特率对话框
    void alertChooseBittmingMode() {
        // setup the alert builder
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setTitle("Choose baudrate");
        // add a list
        String[] bitmmings =    { "20K", "33.33K", "40K", "50K", "66.66K", "80K", "83.33K", "100K", "125K", "200K", "250K", "400K", "500K", "666K", "800K", "1000K"};
        builder.setItems(bitmmings, new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                currentBittmingIndex = which;
               UsbDeviceConnection currentConnection =  libInnoMakerUsbCan.jOpenInnoMakerDevice(libInnoMakerUsbCan.deviceList.indexOf(currentDevice));
                if(currentConnection == null) {
                    controlButton.setText("OPEN");
                } else {
                    controlButton.setText("CLOSE");
                    boolean result = libInnoMakerUsbCan.urbSetupDevice(currentConnection.getFileDescriptor(),currentUsbMode,currentBittmingIndex);
                    recvThread = new Thread(new RunnableRecv());
                    recvThread.start();
                }
            }
        });
        AlertDialog dialog = builder.create();
        dialog.show();
    }
    /// 接收线程
    class  RunnableRecv implements Runnable {

        @Override
        public void run() {
            while (currentDevice != null) {
                    byte []buffer = new byte[24];
                    boolean result = libInnoMakerUsbCan.jRecvInnoMakerDeviceBuf(currentDevice,buffer,24,1000);
                    if(result) {
                        LibInnoMakerUsbCan.InnoMakerHostFrame innoMakerHostFrame =   new   LibInnoMakerUsbCan.InnoMakerHostFrame();
                        innoMakerHostFrame.fromBytes(buffer);
                        if(innoMakerHostFrame.echo_id != 0xffffffff) {
                            LibInnoMakerUsbCan.InnoMakerTxContext innoMakerTxContext =   libInnoMakerUsbCan.innomakerGetTxContext(innoMakerHostFrame.echo_id);
                            if(innoMakerTxContext == null) {
                                Log.i("", "RECV FAIL:Bad Devices Send Bad Echo_ids");
                            } else {
                                libInnoMakerUsbCan.innomakerFreeTxContent(innoMakerTxContext);
                                Message msg =new Message();
//                                msg.obj ="【SEND】" +  libInnoMakerUsbCan.bytesToHexString(buffer) + "\n" ;
                                msg.obj ="【SEND】" + "\n" ;
                                msg.obj += "【TimeStamp】" + libInnoMakerUsbCan.bytesToHexString(libInnoMakerUsbCan.intToByteArray( innoMakerHostFrame.timestamp_us)) + "\n";
                                msg.obj += "【FrameId】" +  libInnoMakerUsbCan.bytesToHexString(libInnoMakerUsbCan.intToByteArray( innoMakerHostFrame.can_id & libInnoMakerUsbCan.CAN_ID_MASK)) + "\n";
                                msg.obj += "【FrameData】" +  libInnoMakerUsbCan.bytesToHexString( innoMakerHostFrame.data) + "\n";
                                mHandler.sendMessage(msg);
                                txCounter++;

                            }
                        }
                        else {
                            Message msg = new Message();
                            /// If Ignore Error Frame
                            if(((innoMakerHostFrame.can_id & libInnoMakerUsbCan.CAN_ERR_FLAG) != 0) && curErrorFilter == 0) {
                                    /// Ignore Error Frame
                            } else {
//                                msg.obj ="【RECV】" +  libInnoMakerUsbCan.bytesToHexString(buffer) +"\n";
                                msg.obj ="【RECV】" + "\n";
                                msg.obj += "【TimeStamp】" + libInnoMakerUsbCan.bytesToHexString(libInnoMakerUsbCan.intToByteArray( innoMakerHostFrame.timestamp_us)) + "\n";
                                msg.obj += "【FrameId】" +  libInnoMakerUsbCan.bytesToHexString(libInnoMakerUsbCan.intToByteArray( innoMakerHostFrame.can_id & libInnoMakerUsbCan.CAN_ID_MASK)) + "\n";
                                msg.obj += "【FrameData】" +  libInnoMakerUsbCan.bytesToHexString( innoMakerHostFrame.data) + "\n";
                                mHandler.sendMessage(msg);
                                rxCounter++;
                            }

                        }
                    } else {

                    }
                    try {
                        Thread.sleep(10);
                    } catch (InterruptedException e) {
                        e.printStackTrace();
                    }

            }
        }
    }


}

